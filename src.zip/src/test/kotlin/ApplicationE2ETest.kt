import com.bwasik.cinema.repository.MovieDetailsRepository
import com.bwasik.cinema.routing.movieDetailsRoute
import com.bwasik.cinema.service.MovieDetailsService
import com.github.tomakehurst.wiremock.WireMockServer
import com.github.tomakehurst.wiremock.client.WireMock
import com.typesafe.config.ConfigFactory
import io.ktor.client.request.*
import io.ktor.client.statement.*
import io.ktor.http.*
import io.ktor.server.config.*
import io.ktor.server.routing.*
import io.ktor.server.testing.*
import kotlinx.coroutines.runBlocking
import org.junit.jupiter.api.*
import org.koin.dsl.module
import org.koin.ktor.ext.get
import org.koin.ktor.plugin.Koin
import org.koin.test.KoinTest
import org.testcontainers.containers.GenericContainer
import org.testcontainers.containers.PostgreSQLContainer

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class ApplicationE2ETest : KoinTest {

    private lateinit var wireMockServer: WireMockServer
    private val redisContainer = GenericContainer("redis:6.2.11").apply {
        withExposedPorts(6379)
    }

    private val postgresContainer = PostgreSQLContainer<Nothing>("postgres:15.2").apply {
        withDatabaseName("test_db")
        withUsername("test_user")
        withPassword("test_password")
    }

    @BeforeAll
    fun setUp() {
        // Start Testcontainers
        redisContainer.start()
        postgresContainer.start()

        // Start WireMock
        wireMockServer = WireMockServer(8080)
        wireMockServer.start()
        WireMock.configureFor("localhost", 8080)

        val movieId = "tt1234567"
        val omdbResponse = """
            {
                "Title": "Test Movie",
                "Year": "2024",
                "Plot": "A test plot",
                "Genre": "Drama",
                "Director": "Test Director",
                "Ratings": []
            }
        """.trimIndent()

        WireMock.stubFor(
            WireMock.get(WireMock.urlEqualTo("/?apikey=test_api_key&i=$movieId"))
                .willReturn(
                    WireMock.aResponse()
                        .withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody(omdbResponse)
                )
        )
    }

    @AfterAll
    fun tearDown() {
        wireMockServer.stop()
        redisContainer.stop()
        postgresContainer.stop()
    }

    @Test
    fun `should fetch movie details and return correct HTTP response`() = testApplication {
        application {
            install(Koin) {
                modules(testModule(postgresContainer, redisContainer))
            }
            routing {
                movieDetailsRoute(get<MovieDetailsService>())
            }
        }

        environment {
            config = ApplicationTestConfig.configureTestEnvironment(
                redisHost = redisContainer.host,
                redisPort = redisContainer.getMappedPort(6379),
                dbUrl = postgresContainer.jdbcUrl,
                dbUser = postgresContainer.username,
                dbPassword = postgresContainer.password,
                omdbBaseUrl = "http://localhost:8080"
            )
        }

        val client = createClient { }
        val response = runBlocking {
            client.get("/api/movie_details/tt1234567")
        }

        Assertions.assertEquals(HttpStatusCode.OK, response.status)
        val responseBody = response.bodyAsText()
        Assertions.assertTrue(responseBody.contains("Mock Movie"))
        Assertions.assertTrue(responseBody.contains("This is a mock plot"))
    }
}

object ApplicationTestConfig {
    fun configureTestEnvironment(
        redisHost: String,
        redisPort: Int,
        dbUrl: String,
        dbUser: String,
        dbPassword: String,
        omdbBaseUrl: String
    ) = mapOf(
        "redis.host" to redisHost,
        "redis.port" to redisPort.toString(),
        "db.url" to dbUrl,
        "db.user" to dbUser,
        "db.password" to dbPassword,
        "omdb.baseUrl" to omdbBaseUrl
    ).let { HoconApplicationConfig(ConfigFactory.parseMap(it)) }
}

fun testModule(postgresContainer: PostgreSQLContainer<*>, redisContainer: GenericContainer<*>): org.koin.core.module.Module {
    return module {
        single { setupDatabase(postgresContainer) }
        single { setupRedis(redisContainer) } // Provide a test Redis connection
        single { MovieDetailsService(get(), get(), get()) } // Inject repository and other dependencies
        single { MovieDetailsRepository } // Provide the repository
    }
}